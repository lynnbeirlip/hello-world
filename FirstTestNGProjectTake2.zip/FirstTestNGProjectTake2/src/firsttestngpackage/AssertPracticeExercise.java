package firsttestngpackage;

class AssertPracticeExercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	
}	